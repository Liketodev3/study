<?php
class PaymentController extends MyAppController
{
}
