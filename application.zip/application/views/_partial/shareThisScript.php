<script type="text/javascript">var switchTo5x=true;</script>
<?php if ( FatApp::getConfig('CONF_USE_SSL', FatUtility::VAR_INT, 0) == 1 ) { ?>
<script type="text/javascript" src="https://ws.sharethis.com/button/buttons.js"></script>
<?php }else{?>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<?php }?>
<script type="text/javascript">stLight.options({publisher: "c1ac1329-15e5-4379-aa5c-30b5671f7265", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>