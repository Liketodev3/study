function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Text hier einf&uuml;gen (CTRL-V) ";
    document.getElementById("btnCancel").value = "abbrechen";
    document.getElementById("btnOk").value = " ok ";   
	}
function writeTitle()
	{
	document.write("<title>Text einf&uuml;gen</title>")
	}

