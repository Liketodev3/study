﻿function loadTxt() {

}
function writeTitle() {
    document.write("<title>" + "Sonderzeichen" + "</title>")
}