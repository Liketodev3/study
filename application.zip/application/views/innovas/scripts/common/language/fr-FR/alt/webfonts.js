function loadTxt() {
    document.getElementById("tab0").innerHTML = "POLICES GOOGLE";
    document.getElementById("tab1").innerHTML = "POLICES BASIQUES";
    }
function writeTitle() {
    document.write("<title>" + "Polices" + "</title>")
    }