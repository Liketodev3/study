﻿function loadTxt() {

}
function writeTitle() {
    document.write("<title>" + "Editeur HTML" + "</title>")
}