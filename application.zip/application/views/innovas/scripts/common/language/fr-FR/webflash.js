function loadTxt() {
    document.getElementById("lblSource").innerHTML = "SOURCE:";
    document.getElementById("lblWidth").innerHTML = "LARGEUR:";
    document.getElementById("lblHeight").innerHTML = "HAUTEUR:";
    document.getElementById("btnCancel").value = "annuler";
    document.getElementById("btnInsert").value = " ins\u00E9rer ";
}

function writeTitle() {
    document.write("<title>Flash</title>")
}