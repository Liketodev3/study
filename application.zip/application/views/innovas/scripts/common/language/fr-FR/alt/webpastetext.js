function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Coller texte ici (CTRL-V) ";
    document.getElementById("btnCancel").value = "Annule";
    document.getElementById("btnOk").value = " Ok ";   
	}
function writeTitle()
	{
	document.write("<title>Colle Texte</title>")
	}

