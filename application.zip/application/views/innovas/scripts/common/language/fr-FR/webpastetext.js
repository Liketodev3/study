function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Collez ici le contenu (CTRL-V) ";
    document.getElementById("btnCancel").value = "annuler";
    document.getElementById("btnOk").value = " ok ";   
	}
function writeTitle()
	{
	document.write("<title>Coller le texte</title>")
	}

