﻿function loadTxt() {

}
function writeTitle() {
    document.write("<title>" + "Specielle tegn" + "</title>")
}