<?php defined('SYSTEM_INIT') or die('Invalid Usage.'); ?>
<script type="text/javascript">
lessonId = '<?php echo $lessonId; ?>';
</script>
<div class="box -padding-20">
	<div id="listItems"></div>
</div>