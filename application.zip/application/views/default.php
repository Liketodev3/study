<?php
defined('SYSTEM_INIT') or die('Invalid Usage.');
?>
This is default view. Seems that view for this action is not created.