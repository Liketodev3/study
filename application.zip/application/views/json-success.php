<?php
defined('SYSTEM_INIT') or die('Invalid Usage.');

FatUtility::dieJsonSuccess($this->variables);